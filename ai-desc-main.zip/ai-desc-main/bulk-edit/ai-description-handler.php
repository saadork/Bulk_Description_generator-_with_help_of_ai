<?php
// ai-description-handler.php

// Handle AJAX request for generating product descriptions
add_action('wp_ajax_generate_product_description', 'handle_generate_product_description');
add_action('wp_ajax_validate_openai_api_key', 'handle_api_key_validation'); // Add this line


function handle_generate_product_description() {
    // Verify nonce for security
    check_ajax_referer('ai_desc_nonce_action', 'nonce');

    // Extract data from AJAX request
    $products = $_POST['products'];
    $api_selection = $_POST['api_selection'];
    $prompt = $_POST['prompt'];
    $params = $_POST['params'];

    // Initialize an array to store generated descriptions
    $descriptions = [];

    // Determine which API to use for description generation
    if ($api_selection === 'aiengine') {
        $descriptions = handle_aiengine_api_call($products, $prompt, $params);
    } elseif ($api_selection === 'openai') {
        $descriptions = handle_openai_api_call($products, $prompt, $params);
    } else {
        wp_send_json_error('Invalid API selection.');
    }

    // Store generated descriptions
    store_ai_generated_descriptions($descriptions);

    // Schedule the product update
    schedule_product_update();

    // Return a success message
    wp_send_json_success('Descriptions updated successfully.');
}

function store_ai_generated_descriptions($descriptions) {
    $product_ids = [];
    foreach ($descriptions as $product_id => $description) {
        set_transient("ai_desc_for_product_$product_id", $description, HOUR_IN_SECONDS);
        $product_ids[] = $product_id;
    }
    set_transient('ai_desc_product_ids', $product_ids, DAY_IN_SECONDS);
}

function handle_aiengine_api_call($products, $prompt, $params) {
    // Logic to call AI Engine API and generate descriptions
    // Return an array mapping product IDs to generated descriptions
    return [];
}

function handle_openai_api_call($products, $prompt, $params) {
    // Logic to call OpenAI API and generate descriptions
    // Return an array mapping product IDs to generated descriptions
    return [];
}