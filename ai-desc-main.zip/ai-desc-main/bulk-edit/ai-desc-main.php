<?php
// ai-desc-main.php

// Include the Business Profiler functions
require_once AI_DESC_PATH . 'business-profile/business-profiler.php';

// Add AI Desc admin page
require_once AI_DESC_PATH . 'admin/ai-desc-admin.php';

// Require ai-description-handler.php and ajax-handler.php in /ai-desc/bulk-edit/
require_once AI_DESC_PATH . 'bulk-edit/ai-description-handler.php';
require_once AI_DESC_PATH . 'bulk-edit/ajax-handler.php';

function ai_desc_enqueue_admin_assets() {
    $screen = get_current_screen();

    // Enqueue scripts for the edit-product screen
    if ($screen->id === 'edit-product') {
        if (!did_action('wp_enqueue_media')) {
            wp_enqueue_media();
        }
        wp_enqueue_style('thickbox');
        wp_enqueue_script('thickbox');
        wp_enqueue_script('ai-popup-script', plugins_url('ai-popup.js', __FILE__), ['jquery'], '1.0', true);
        wp_localize_script('ai-popup-script', 'aiDescData', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ai_desc_nonce_action')
        ));
        wp_enqueue_style('ai-popup-style', plugins_url('popup-style.css', __FILE__));
    }

    // Enqueue scripts for the AI Desc Settings page
    if ('toplevel_page_ai_desc_settings' === $screen->id) {
        wp_enqueue_style('ai-desc-admin-style', plugins_url('admin/ai-desc-admin-style.css', dirname(__FILE__)));
        wp_enqueue_script('ai-desc-admin', plugins_url('admin/ai-desc-admin.js', dirname(__FILE__)), array('jquery'), null, true);
        wp_enqueue_script('ai-desc-business-profile', plugins_url('business-profile/business-profile.js', dirname(__FILE__)), array('jquery'), null, true);
    }

    // Enqueue validation script globally for the admin side
    wp_enqueue_script('ai-desc-validation', plugins_url('admin/ai-desc-validation.js', dirname(__FILE__)), array('jquery'), '1.0', true);
    wp_localize_script('ai-desc-validation', 'aiDescValidationData', array(
        'ajaxurl' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('ai_desc_nonce_action')
    ));
}

add_action('admin_enqueue_scripts', 'ai_desc_enqueue_admin_assets');

// Add custom bulk action to edit products
add_filter('bulk_actions-edit-product', function ($bulk_actions) {
    $bulk_actions['generate_ai_description'] = 'Write Descriptions with AI Desc';
    return $bulk_actions;
});

// Inject the HTML for the popup
add_action('admin_footer', function () {
    $current_screen = get_current_screen();
    if ($current_screen) {
        // Print the current screen ID for debugging
        echo '<p>Current Screen ID: ' . $current_screen->id . '</p>';
        
        // Include the popup form
        if ($current_screen->id === 'edit-product') {
            echo AI_DESC_PATH . 'bulk-edit/popup-form.php';
            die(); // Temporarily stop the script to view the output.
            include AI_DESC_PATH . 'bulk-edit/popup-form.php';
        }
    }
});

// Trigger the bulk action handler
add_action('admin_action_generate_ai_description', function () {
    require_once AI_DESC_PATH . 'bulk-edit/bulk-action-handler.php';
});

// Include the schedule-and-update functionality
require_once AI_DESC_PATH . 'bulk-edit/schedule-and-update.php';
?>