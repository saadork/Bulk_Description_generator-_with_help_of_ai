jQuery(document).ready(function($) {
    // Event listener for bulk action
    $('#doaction, #doaction2').click(function(e) {
        console.log('Bulk action button clicked');
        var action = $(this).prev('select').val();
        if (action === 'generate_ai_description') {
            e.preventDefault();
            var selectedProducts = [];
            $('input[name="post[]"]:checked').each(function() {
                selectedProducts.push($(this).val());
            });

            if (selectedProducts.length > 0) {
                $("#ai-popup").show();
                $("#ai-popup-form").data('products', selectedProducts);
            } else {
                alert('Please select products to generate descriptions.');
            }
        }
    });

    // Handler for API-Key validation
    $('#api-key-validate').click(function(e) {
        e.preventDefault();
        var apiKey = $('#api-key').val();

        // AJAX data to send for validation
        var data = {
            'action': 'validate_openai_api_key', // WordPress AJAX action hook
            'nonce': aiDescData.nonce,           // Nonce for security
            'api_key': apiKey                    // The API key from the form
        };

        // Perform the AJAX request to validate the API key
        $.post(ajaxurl, data, function(response) {
            if(response.success) {
                alert('API Key is valid.');
                // Additional logic for successful validation
            } else {
                alert('API Key is invalid. Please check and try again.');
                // Handle invalid API key
            }
        });
    });

    // Handler for popup submission
    $('#ai-popup-submit').click(function(e) {
        e.preventDefault();
        var selectedProducts = $("#ai-popup-form").data('products');
        var apiSelection = $('#api-selection').val();
        var apiKey = $('#api-key').val();
        var businessProfile = collectBusinessProfile();
        var selectedPrompt = $('#selected-prompt').val();
        var additionalInstructions = $('#additional-instructions').val();

        // Combining selected prompt and additional instructions
        var selectedPromptData = selectedPrompt + "\n" + additionalInstructions;

        var ajaxData = {
            action: 'generate_product_description',
            nonce: aiDescData.nonce, // Directly use the nonce value
            products: selectedProducts,
            api_selection: apiSelection,
            api_key: apiKey,
            business_profile: businessProfile,
            selected_prompt_data: selectedPromptData
        };

        $.post(ajaxurl, ajaxData, function(response) {
            $("#ai-popup").hide();
            if (response.success) {
                alert('Descriptions are being generated. This may take some time.');
            } else {
                alert('Error: ' + response.data);
            }
        });
    });

    function collectBusinessProfile() {
        // Logic to collect and return business profile settings
        return {
            profile: $('#business-profile').val(),
            additional: $('#business-additional').val(),
            values: $('#business-values').val(),
            tone: $('#business-tone').val(),
            audience: $('#business-audience').val(),
            exclude: $('#business-exclude').val(),
            include: $('#business-include').val()
        };
    }
});