<?php
// Schedule product updates
function schedule_product_update() {
    if (!wp_next_scheduled('update_product_descriptions')) {
        wp_schedule_event(time(), 'custom_seven_seconds', 'update_product_descriptions');
    }
}

// Hook to trigger the update function
add_action('update_product_descriptions', 'update_products_with_ai_description');

// Function to update products with AI descriptions
function update_products_with_ai_description() {
    // Retrieve a list of product IDs that need updating
    $product_ids = get_transient('ai_desc_product_ids');

    if (!empty($product_ids)) {
        $product_id = array_shift($product_ids); // Get the first product ID
        $description = get_transient("ai_desc_for_product_$product_id");

        if ($description) {
            $product = wc_get_product($product_id);
            if ($product) {
                $product->set_description($description);
                $product->save();
                delete_transient("ai_desc_for_product_$product_id"); // Clear the transient after updating
            }
        }

        if (!empty($product_ids)) {
            set_transient('ai_desc_product_ids', $product_ids, HOUR_IN_SECONDS);
        } else {
            wp_clear_scheduled_hook('update_product_descriptions'); // Clear schedule when done
            send_completion_notification();
        }
    }
}

// Custom interval for WP-Cron
add_filter('cron_schedules', 'add_custom_cron_schedule');
function add_custom_cron_schedule($schedules) {
    $schedules['custom_seven_seconds'] = array(
        'interval' => 7, // 7 seconds
        'display'  => __('Every Seven Seconds')
    );
    return $schedules;
}

// Function to send completion notification
function send_completion_notification() {
    error_log('AI Description Update Completed.');

    // Optionally clear cache or notify the user to do so manually
    // Example for WP Rocket:
    // if (function_exists('rocket_clean_domain')) {
    //     rocket_clean_domain();
    // }

    // Notify the user to clear cache manually
    add_action('admin_notices', 'show_cache_clearing_notice');
}

// Function to display cache clearing notice
function show_cache_clearing_notice() {
    echo '<div class="notice notice-success is-dismissible"><p>AI description generation complete. Please clear cache.</p></div>';
}
