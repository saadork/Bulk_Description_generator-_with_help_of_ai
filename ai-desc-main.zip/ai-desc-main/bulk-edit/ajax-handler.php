<?php
// ajax_handler.php

require_once AI_DESC_PATH . 'API/verify-api-key.php';

function handle_api_key_validation() {
    // Check nonce for security
    check_ajax_referer('ai_desc_nonce_action', 'nonce');

    // Get the API key from the AJAX request
    $api_key = isset($_POST['api_key']) ? sanitize_text_field($_POST['api_key']) : '';

    if (!empty($api_key)) {
        $is_valid = verify_openai_api_key($api_key);
        if ($is_valid) {
            // The API key is valid
            // Mask the API key
            $masked_api_key = maskApiKey($api_key);
            // Save the masked API key state
            update_option('ai_desc_api_key_state', $masked_api_key);
            wp_send_json_success('API Key is valid.');
        } else {
            // The API key is invalid
            wp_send_json_error('API Key is invalid.');
        }
    } else {
        // No API key provided
        wp_send_json_error('No API Key provided.');
    }
}

// Function to mask the API key
function maskApiKey($apiKey) {
    return 'sk-************' . substr($apiKey, -4); // Example masking
}
// Hook the function to handle the AJAX request
add_action('wp_ajax_validate_openai_api_key', 'handle_api_key_validation');