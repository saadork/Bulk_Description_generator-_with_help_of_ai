<?php
echo 'popup-form.php included';
add_action('admin_footer', function () {
    console.log('ai_description_popup_html function called');
    function ai_description_popup_html() {
        ?>
        <div id="ai-popup" style="display:none;">
            <form id="ai-popup-form">
                <!-- OpenAI API-Key Input -->
                <label for="api-key">OpenAI API-Key:</label>
                <input type="text" id="api-key" name="api_key">
                <button id="api-key-validate">Validate Key</button>

                <!-- API Selection Dropdown -->
                <label for="api-selection">Choose API to use:</label>
                <select id="api-selection" name="api_selection">
                    <option value="custom">AI Engine</option>
                    <option value="openai">OpenAI</option>
                </select>

                <!-- Business Profile Inputs -->
                <div id="business-profile-section">
                    <!-- Add fields for business profile inputs -->
                </div>

                <!-- Prompt Selection Dropdown -->
                <label for="selected-prompt">Choose Prompt:</label>
                <select id="selected-prompt" name="selected_prompt">
                    <!-- Add options for prompt templates -->
                </select>

                <!-- Additional Instructions -->
                <label for="additional-instructions">Any Other Instructions:</label>
                <textarea id="additional-instructions" name="additional_instructions"></textarea>

                <!-- Submit Button -->
                <input type="submit" id="ai-popup-submit" value="Generate Descriptions">
            </form>
        </div>
        <?php
    }
    ai_description_popup_html();
});
?>