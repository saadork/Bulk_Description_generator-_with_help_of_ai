<?php
// bulk-action-handler.php
// This file defines the callback function for the custom bulk action.
// It prepares product information for AI description generation.

function handle_generate_ai_description_action() {
    // Verify nonce for security
    check_admin_referer('generate-ai-description-action');

    if (!isset($_POST['product_ids'])) {
        wp_die('No products selected for AI description generation.');
    }

    $product_ids = $_POST['product_ids'];
    $product_titles = [];

    // Prepare product titles
    foreach ($product_ids as $product_id) {
        $product = wc_get_product($product_id);
        if ($product) {
            $product_titles[$product_id] = $product->get_name();
        }
    }

    // Store product titles for later use
    set_transient('ai_desc_product_ids', $product_ids, HOUR_IN_SECONDS);

    // Direct to the AI description handler
    wp_redirect(admin_url('admin-ajax.php?action=generate_product_description&nonce=' . wp_create_nonce('your_nonce_name')));
    exit;
}

add_action('admin_action_generate_ai_description', 'handle_generate_ai_description_action');

// Function to display the generated description on the product page
function insert_generated_description() {
    global $product;
    
    // Check if there is a generated description for the current product
    if ($generated_description = get_transient("ai_desc_for_product_" . $product->get_id())) {
        echo '<div class="generated-description">' . esc_html($generated_description) . '</div>';
    }
}
// Hook to display the generated description on the WooCommerce product page
add_action('woocommerce_single_product_summary', 'insert_generated_description', 25);