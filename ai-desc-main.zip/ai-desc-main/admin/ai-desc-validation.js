// ai-desc-validation.js
jQuery(document).ready(function($) {
    $('#api-key-validate').click(function(e) {
        e.preventDefault();
        var apiKey = $('#api-key').val();

        // Regular expression for OpenAI API key pattern
        var pattern = /^sk-[A-Za-z0-9]+$/;

        if (!pattern.test(apiKey)) {
            alert('Invalid API Key format.');
            return; // Stop the function if the pattern does not match
        }

        // AJAX request is made only if the pattern matches
        $.ajax({
            type: 'POST',
            url: aiDescValidationData.ajaxurl, // WordPress AJAX handler
            data: {
                action: 'validate_openai_api_key',
                api_key: apiKey,
                nonce: aiDescValidationData.nonce // Use the nonce from wp_localize_script()
            },
            success: function(response) {
                if (response.success) {
                    alert('API Key is valid.');

                    // Mask the API key
                    $('#api-key').val(maskApiKey(apiKey));

                    // Change button text and disable it
                    $('#api-key-validate').text('API-Key Active').prop('disabled', true);

                    // Add clickable text/link to replace API key
                    if ($('#replace-api-key').length === 0) { // Check if the link doesn't already exist
                        $('<p><a href="#" id="replace-api-key">Click here to replace current API-Key</a></p>').insertAfter('#api-key-validate');
                    }
                } else {
                    alert('API Key is invalid.');
                }
            },
            error: function(xhr, status, error) {
                console.error(error);
            }
        });
    });

    // Function to mask the API key
    function maskApiKey(apiKey) {
        return apiKey.substr(0, 3) + '*'.repeat(apiKey.length - 6) + apiKey.substr(-3);
    }
});