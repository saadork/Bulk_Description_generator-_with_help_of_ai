// ai-desc-admin.js
jQuery(document).ready(function($) {
    // Function to handle tab clicks
    function handleTabClick(tab) {
        // Remove active class from all tabs
        $('.nav-tab').removeClass('active');
        
        // Add active class to the clicked tab
        $(tab).addClass('active');
        
        // Get the ID of the selected tab
        var tabId = $(tab).attr('href');
        
        // Hide all tab contents
        $('.tab-content').hide();
        
        // Show the content of the selected tab
        $(tabId).show();
    }

    // Function to set the first tab as active by default
    function setDefaultTab() {
        // Remove active class from all tabs
        $('.nav-tab').removeClass('active');
        
        // Add active class to the first tab
        $('.nav-tab:first').addClass('active');
        
        // Show the content of the first tab
        var firstTabId = $('.nav-tab:first').attr('href');
        $(firstTabId).show();
    }

    // Event listener for tab clicks
    $('.nav-tab').click(function(e) {
        e.preventDefault();
        handleTabClick(this);
    });

    // Event listener for clicks outside of tabs
    $(document.body).click(function(e) {
        // Check if the clicked element is not a tab or a descendant of a tab
        if (!$(e.target).closest('.nav-tab').length) {
            // Get the last active tab
            var lastActiveTab = $('.nav-tab.active');
            if (lastActiveTab.length) {
                handleTabClick(lastActiveTab);
            }
        }
    });

    // Set the first tab as active by default
    setDefaultTab();
});