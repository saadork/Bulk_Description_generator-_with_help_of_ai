// ai-desc-replace-key.js
jQuery(document).ready(function(jQuery) {
    // Function to handle replacing the API key
    jQuery(document).on('click', '#replace-api-key', function(e) {
        e.preventDefault();
        jQuery('#api-key').val('').prop('disabled', false);
        jQuery('#api-key-validate').text('Validate Key').prop('disabled', false);
    });
});
