<?php
// ai-desc-admin.php

define('AI_DESC_ADM_PATH', dirname(__FILE__) . '/');

function ai_desc_add_admin_menu() {
    // Main menu page - AI Desc Settings
    add_menu_page('AI Desc Settings', 'AI Desc', 'manage_options', 'ai_desc_settings', 'ai_desc_settings_page', 'dashicons-admin-generic', 110);
}

add_action('admin_menu', 'ai_desc_add_admin_menu');

function ai_desc_settings_page() {
    // Include PHP files and store their contents in variables for other tabs
    ob_start();
    include AI_DESC_ADM_PATH . 'ai-desc-license-page.php';
    $license_content = ob_get_clean();
    
    ob_start();
    include AI_DESC_ADM_PATH . 'ai-desc-api-key-page.php';
    $apikey_content = ob_get_clean();

    ob_start();
    include AI_DESC_ADM_PATH . 'ai-desc-documentation-page.php';
    $documentation_content = ob_get_clean();

    ?>
    <div class="wrap">
        <h1>AI Desc Settings</h1>
        <!-- Tab navigation for settings -->
        <h2 class="nav-tab-wrapper">
            <a href="#tab1" class="nav-tab">License</a>
            <a href="#tab2" class="nav-tab">API-Key</a>
            <a href="#tab3" class="nav-tab">Business Profile</a>
            <a href="#tab4" class="nav-tab">Documentation</a>
        </h2>
        <!-- Content for each tab -->
        <div id="tab1" class="tab-content">
            <?php echo $license_content; ?>
        </div>
        <div id="tab2" class="tab-content">
            <?php echo $apikey_content; ?>
        </div>
        <div id="tab3" class="tab-content">
            <?php
                // Directly include the business profile settings page here
                include AI_DESC_ADM_PATH . 'business-profile-page.php';
            ?>
        </div>
        <div id="tab4" class="tab-content">
            <?php echo $documentation_content; ?>
        </div>
    </div>
    <?php
}

// Enqueue ai-desc-admin-style.css and ai-desc-admin.js
function ai_desc_enqueue_settings_page_assets() {
    // Enqueue ai-desc-admin-style.css
    wp_enqueue_style('ai-desc-admin-style', plugins_url('ai-desc-admin-style.css', __FILE__));

    // Enqueue ai-desc-admin.js
    wp_enqueue_script('ai-desc-admin', plugins_url('ai-desc-admin.js', __FILE__), array('jquery'), null, true);
}

// Enqueue ai-desc-replace-key.js only for the API key admin page
function enqueue_api_key_admin_scripts($hook) {
    // Check if we are on the API key admin page
    if ($hook === 'toplevel_page_ai_desc_settings') {
        // Enqueue the JavaScript file with jQuery as a dependency
        wp_enqueue_script('ai-desc-replace-key', plugins_url('ai-desc-replace-key.js', __FILE__), array('jquery'), '1.0.1', true);
    }
}

// Combine both functions into a single add_action call
add_action('admin_enqueue_scripts', 'ai_desc_enqueue_settings_page_assets');
add_action('admin_enqueue_scripts', 'enqueue_api_key_admin_scripts');
?>