<?php
// business-profile-page.php

// Check if user has the right permissions
if (!current_user_can('manage_options')) {
    return;
}

?>
<div class="wrap">
    <h1>Business Profile</h1>
    <form method="post" action="options.php">
        <?php
        settings_fields('business_profile');
        do_settings_sections('business_profile');
        submit_button(); 
        ?>
    </form>
</div>