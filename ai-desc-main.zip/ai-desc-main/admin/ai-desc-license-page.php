<!-- ai-desc-license-page.php -->
<label for="license-key">License:</label>
<input type="text" id="license-key" name="license_key">
<button id="license-validate">Validate License</button>
<p>Note: Please validate your AI Desc license key to activate the plugin.</p>