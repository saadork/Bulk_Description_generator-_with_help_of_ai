<!-- ai-desc-api-key-page.php -->
<?php $api_key_state = get_option('ai_desc_api_key_state'); ?>
<label for="api-key">OpenAI API-Key:</label>
<input type="text" id="api-key" name="api_key" value="<?php echo esc_attr($api_key_state); ?>">
<button id="api-key-validate" <?php echo !empty($api_key_state) ? 'disabled' : ''; ?>>
    <?php echo !empty($api_key_state) ? 'API-Key Active' : 'Validate Key'; ?>
</button>
<?php if (!empty($api_key_state)) : ?>
    <p><a href="#" id="replace-api-key">Click here to replace current API-Key</a></p>
<?php endif; ?>
<p>Note: Please validate your OpenAI API-key to enable the plugin's AI-features.</p>
