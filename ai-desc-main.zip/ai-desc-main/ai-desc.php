<?php
// ai-desc.php
/**
 * Plugin Name: AI Desc by SemWit
 * Plugin URI:  https://www.semwit.com/
 * Description: AI Desc is a WooCommerce product description generator powered by OpenAI and AI Engine. AI Desc is a highly customizable AI content tool that lets you generate selling and SEO-optimized WooCommerce product descriptions in bulk.
 * Version:     1.0.0
 * Author:      Lars LJ
 * Author URI:  https://www.semwit.com/
 */

## Will be dual licensed under the MIT and GPL licenses upon publishing by SemWit ##
# http://www.opensource.org/licenses/mit-license.php #
# http://www.gnu.org/licenses/gpl.html #
# Mutual NDA with all developers

if (!function_exists('add_action')) {
    die('Error: Must run in WordPress context.');
}

define('AI_DESC_PATH', plugin_dir_path(__FILE__));

// Include the main functionality file using the defined constant
require_once AI_DESC_PATH . 'bulk-edit/ai-desc-main.php';
?>