<?php
// business-profiler.php

function register_business_profile_settings() {
    // Register settings for business profile
    register_setting('business_profile', 'profile');
    register_setting('business_profile', 'additional');
    register_setting('business_profile', 'values');
    register_setting('business_profile', 'tone');
    register_setting('business_profile', 'audience');
    register_setting('business_profile', 'exclude');
    register_setting('business_profile', 'include');
}

add_action('admin_init', 'register_business_profile_settings');

function business_profile_settings_section() {
    // Register a new section in the "business_profile" page
    add_settings_section('business_profile_section', 'Business Profile Details', 'business_profile_section_callback', 'business_profile');

    // Register new fields in the "business_profile_section" section, inside the "business_profile" page
    add_settings_field('profile', 'Company Profile', 'business_profile_field_callback', 'business_profile', 'business_profile_section', array('label_for' => 'profile'));
    add_settings_field('additional', 'Additional Information', 'business_profile_field_callback', 'business_profile', 'business_profile_section', array('label_for' => 'additional'));
    add_settings_field('values', 'Company Values', 'business_profile_field_callback', 'business_profile', 'business_profile_section', array('label_for' => 'values'));
    add_settings_field('tone', 'Brand Tone', 'business_profile_field_callback', 'business_profile', 'business_profile_section', array('label_for' => 'tone'));
    add_settings_field('audience', 'Target Audience', 'business_profile_field_callback', 'business_profile', 'business_profile_section', array('label_for' => 'audience'));
    add_settings_field('exclude', 'Words to Exclude', 'business_profile_field_callback', 'business_profile', 'business_profile_section', array('label_for' => 'exclude'));
    add_settings_field('include', 'Words to Include', 'business_profile_field_callback', 'business_profile', 'business_profile_section', array('label_for' => 'include'));
}

function business_profile_field_callback($args) {
    $option = get_option($args['label_for']);
    echo "<input type='text' id='{$args['label_for']}' name='{$args['label_for']}' value='".esc_attr($option)."' />";
}

function business_profile_section_callback() {
    echo '<p>Fill in your business / brand profile here for more tailored AI responses.</p>';
}

add_action('admin_init', 'business_profile_settings_section');