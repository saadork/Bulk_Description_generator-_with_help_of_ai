// business-profile.js
jQuery(document).ready(function($) {
    // Event listener for opening the business profile settings
    $('#ai-popup-business-profile').click(function(e) {
        e.preventDefault();
        $("#business-profile-popup").show();
    });

    // Handler for business profile submission
    $('#business-profile-submit').click(function(e) {
        e.preventDefault();
        let businessProfile = collectBusinessProfile();
        // Store the business profile in a hidden field or use it directly in your API call
        $('#hidden-business-profile').val(JSON.stringify(businessProfile));
        $("#business-profile-popup").hide();
    });

    function collectBusinessProfile() {
        // Logic to collect and return business profile settings
        return {
            profile: $('#business-profile').val(),
            additional: $('#business-additional').val(),
            values: $('#business-values').val(),
            tone: $('#business-tone').val(),
            audience: $('#business-audience').val(),
            exclude: $('#business-exclude').val(),
            include: $('#business-include').val()
        };
    }
});