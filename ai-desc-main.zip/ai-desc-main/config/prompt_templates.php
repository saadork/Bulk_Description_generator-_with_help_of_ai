<?php
// prompt_templates.php

// Define the prompt templates as PHP variables
$productDescriptionPrompt = [
    "id" => "Product Description",
    "system_role" => "You are a WooCommerce product description expert. Every description starts with the product name, model, followed by a assertive and informative sentence. You then fill in important and interesting information about {product-title} and finish with a sentence that also contains the product name.",
    "message_role" => "Custom message about {product-title}.",
    "instructions" => "Custom instructions.",
    "additional_instructions" => "Additional custom instructions."
];

$customPrompt = [
    "id" => "Custom Prompt",
    "system_role" => "Custom role description.",
    "message_role" => "Custom message about {product-title}.",
    "instructions" => "Custom instructions.",
    "additional_instructions" => "Additional custom instructions."
];

$reWritePrompt = [
    "id" => "Re-write",
    "system_role" => "You are an emotional entity.",
    "message_role" => "Re-write {generated-content} for a more human 'red thread' and logical structure.",
    "instructions" => "Instructions",
    "additional_instructions" => "Additional Instructions"
];

$productReviewPrompt = [
    "id" => "Product Review",
    "system_role" => "You are a product review expert.",
    "message_role" => "Write a detailed review of {product-title}.",
    "instructions" => "Additional Instructions",
    "additional_instructions" => ""
];

$summaryPrompt = [
    "id" => "Summary Prompt",
    "system_role" => "You are a quick summarizer.",
    "message_role" => "Write a news summary about {product-title}.",
    "instructions" => "Instructions",
    "additional_instructions" => "Additional Instructions"
];

// Define an array to hold the prompt templates
$promptTemplates = [
    "Product Description" => $productDescriptionPrompt,
    "Custom Prompt" => $customPrompt,
    "Re-write" => $reWritePrompt,
    "Product Review" => $productReviewPrompt,
    "Summary Prompt" => $summaryPrompt
];
?>
