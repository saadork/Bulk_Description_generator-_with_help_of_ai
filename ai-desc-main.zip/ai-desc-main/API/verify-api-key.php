<?php
// verify-api-key.php
// This script validates the OpenAI API key.

function verify_openai_api_key($api_key) {
    // Define the endpoint for a simple OpenAI API call
    $api_url = 'https://api.openai.com/v1/completions';

    // Set up the headers with the API key
    $headers = array(
        'Authorization' => 'Bearer ' . $api_key,
        'Content-Type' => 'application/json'
    );

    // Make the API request
    $response = wp_remote_get($api_url, array('headers' => $headers));

    // Check for WP error
    if (is_wp_error($response)) {
        return false; // API call failed
    }

    // Check the response status code
    $status_code = wp_remote_retrieve_response_code($response);

    // A successful request should return a 200 status code
    return ($status_code === 200);
}