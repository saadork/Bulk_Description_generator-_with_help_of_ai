<?php
require_once 'config/ai-engine-models.php';

add_action('rest_api_init', function () {
    register_rest_route('semwit-product-rating/v1', '/generate-description/', array(
        'methods' => 'POST',
        'callback' => 'generate_product_description',
        'permission_callback' => function () {
            return current_user_can('edit_posts');
        }
    ));
});

function generate_product_description($request) {
    global $MWAI_OPENAI_MODELS;

    $data = $request->get_json_params();
    $product_titles = $data['product_titles']; // Array of product titles
    $selectedModelId = $data['model'] ?? 'gpt-3.5-turbo'; // Default model if not provided
    $businessProfile = $data['businessProfile']; // Business profile information
    $selectedPromptData = $data['selectedPromptData']; // The selected prompt data

    // Find the selected model or default to GPT-3.5 Turbo if not found
    $selectedModel = $MWAI_OPENAI_MODELS[$selectedModelId] ?? $MWAI_OPENAI_MODELS['gpt-3.5-turbo'];

    $generated_descriptions = [];

    foreach ($product_titles as $title) {
        $conversation = [
            ["role" => "system", "content" => $businessProfile],
            ["role" => "system", "content" => "You are a large language model trained by Open AI. Give helpful and creative responses based on the user's input. Reply in Markdown and Norwegian language."],
            ["role" => "user", "content" => "Give extensive and helpful information about $title. Ensure comprehensive coverage of the topics to the best of your ability. Follow Google's helpful content guidelines and a basic journalistic approach when you structure the articles. På norsk."]
            ["role" => "system", "content" => $selectedPromptData]
        ];

        $api_response = wp_remote_post('AI_ENGINE_API_ENDPOINT', array(
            'body' => json_encode([
                'model' => $selectedModel['model'],
                'messages' => $conversation,
                'max_tokens' => $selectedModel['maxTokens'],
                'temperature' => 0.6,
                'top_p' => 0.9,
                'frequency_penalty' => 0.5,
                'presence_penalty' => 0.5
                // Other parameters like temperature, top_p, etc., can be added here if needed
            ]),
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer YOUR_API_KEY'
            )
        ));

        if (is_wp_error($api_response)) {
            continue; // Skip on error and proceed to the next title
        }

        // Extract the generated description from the response
        $response_body = wp_remote_retrieve_body($api_response);
        $response_data = json_decode($response_body, true);
        $generated_description = $response_data['choices'][0]['message']['content'] ?? '';
        $generated_descriptions[$title] = $generated_description;

    // End of the foreach loop    
    }

    return $generated_descriptions;
}