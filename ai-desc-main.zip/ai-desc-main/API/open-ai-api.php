<?php
// Load and parse the models from engine_options.json
$models_json = file_get_contents(plugin_dir_path(__FILE__) . '/config/engine_options.json');
$gptModels = json_decode($models_json, true);
$selectedPromptData = ...; // Logic will be made in ai-popup.js / other file and is passed here.

function generate_product_descriptions($product_titles, $selectedModelId = 'gpt-3.5-turbo', $selectedPromptData) {
    global $gptModels;

    // Find the selected model or default to the first model if not found
    $selectedModel = array_filter($gptModels, function ($model) use ($selectedModelId) {
        return $model['id'] === $selectedModelId;
    })[0] ?? $gptModels[0];

    // Construct the API URL based on the selected model
    $api_url = 'https://api.openai.com/v1/completions' . $selectedModel['id'] . '/completions';
    $api_key = 'YOUR_API_KEY'; // Replace with your actual API key

    foreach ($product_titles as $title) {
        $conversation = [
            ["role" => "system", "content" => $businessProfile], // Business profile information
            ["role" => "system", "content" => "You are a large language model trained by Open AI. Give helpful and creative response based on the user's input. Reply in Markdown and Norwegian language."],
            ["role" => "user", "content" => "Give extensive and helpful information about $title. For each one you generate, ensuring a comprehensive coverage of the topics to the best of your ability. Follow Google's helpful content guidelines and a basic journalistic approach when you structure the articles. På norsk."],
            ["role" => "system", "content" => $selectedPromptData] // Add the selected prompt
        ];

        $response = wp_remote_post($api_url, [
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type' => 'application/json'
            ],
            'body' => json_encode([
                'model' => $selectedModel['id'], // Use the selected model's ID
                'messages' => $conversation,
                'max_tokens' => 4000,
                'temperature' => 0.6,
                'top_p' => 0.9,
                'frequency_penalty' => 0.5,
                'presence_penalty' => 0.5
            ])
        ]);

        if (is_wp_error($response)) {
            // Handle errors
            continue;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        $generated_description = $data['choices'][0]['message']['content'];

        // Logic to update the product with the generated description
        update_product_description($title, $generated_description);
    }

    return 'Product description generation complete!';
}

function update_product_description($title, $generated_description) {
    // Implement logic to find the product by title and update its description.
    // Query WooCommerce database for product ID by its title, then WooCommerce functions update product description.
}